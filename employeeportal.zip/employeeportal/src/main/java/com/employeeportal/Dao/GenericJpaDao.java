package com.employeeportal.Dao;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public abstract class GenericJpaDao<T, Type extends Serializable> implements GenericDao<T, Type> {

	@PersistenceContext
	EntityManager manager;
	
	private Class<T> persistedClass;
	
	
	protected GenericJpaDao() {
		
	}

	protected GenericJpaDao(Class<T> persistedClass) {
		this.persistedClass = persistedClass;
	}
	

	@Override
	public List<T> findAll() {
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<T> query = builder.createQuery(persistedClass);
		Root<T> t = query.from(persistedClass);
		query.select(t);
		TypedQuery<T> q = manager.createQuery(query);
		return  q.getResultList();
	}

	@Override
	public T findOne(Type id) {
		return this.manager.find(persistedClass, id);
	}

	@Override
	@Transactional
	public boolean save(T entity) {
		try {
			this.manager.merge(entity);
			this.manager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			
			e.printStackTrace();
			return false;
		}
	}

	@Override
	@Transactional
	public boolean delete(Type id) {
		
		try {
			this.manager.remove(findOne(id));
			this.manager.getTransaction().commit();;
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	@Transactional
	public boolean update(T entity) {
		try {
			this.manager.merge(entity);
			this.manager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}	
		
	}
	}

