package com.employeeportal.Dao;

import java.io.Serializable;

import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public interface GenericDao<T, Type extends Serializable> {

	    List<T> findAll();
		
		T findOne(Type type);
		
		boolean save(T t);
		
		boolean delete(Type type);

		boolean update(T t);

}
