package com.employeeportal.Dao;

import org.springframework.stereotype.Repository;

import com.employeeportal.Dao.GenericDao;
import com.employeeportal.model.Employee;

@Repository
public interface EmployeeRepository extends GenericDao<Employee, Integer>{

}
 