package com.employeeportal.servicceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeeportal.Dao.EmployeeRepository;
import com.employeeportal.model.Employee;
import com.employeeportal.sevice.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public boolean saveEmp(Employee employee) {
		employeeRepository.save(employee);
		return true;
	}

	@Override
	public boolean update(Employee empupdate) {
		employeeRepository.update(empupdate);
		return true;
	}

	@Override
	public List<Employee> findAll() {
		return employeeRepository.findAll();
	}

	@Override
	public Employee findOne(Integer id) {
		return employeeRepository.findOne(id);
	}
	
	/*
	 * @Override public boolean delete(Integer id) {
	 * employeeRepository.delete(id); 
	 * return true;
	 *  }
	 */

}
