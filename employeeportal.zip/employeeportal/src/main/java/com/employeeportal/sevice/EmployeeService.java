package com.employeeportal.sevice;

import java.util.List;

import org.springframework.stereotype.Service;

import com.employeeportal.model.Employee;

@Service
public interface EmployeeService {
	
	public boolean saveEmp(Employee employee);
	
	//public boolean delete(Integer id);
	
	public boolean update(Employee empupdate);
	
	public List<Employee> findAll();
	
	public Employee findOne(Integer id);

}
