package com.employeeportal.restController;

import java.util.List;

import javax.sql.DataSource;
import javax.xml.ws.Response;

import org.apache.commons.logging.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.employeeportal.model.Employee;
import com.employeeportal.sevice.EmployeeService;

@CrossOrigin(origins = "*", maxAge = 3600)

@RequestMapping("/employeepotral")
@RestController
public class EmpController {
	
	private static final Logger LOG = LoggerFactory.getLogger(RestController.class);

	@Autowired
	DataSource dataSource;
	@Autowired
	private  EmployeeService employeeService;
	
	
	@RequestMapping(value ="/employeeList",method= RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
			public List<Employee> listofEMP(@RequestParam String org_name) throws Exception  {
		
		             return	employeeService.findAll();
					
				
				
	}
	
	@RequestMapping(value ="/employeeRegister",method= RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public /*Employee */ void addEmp(@RequestBody Employee emp) throws Exception  {


		try {
			Employee employee =new Employee();
			employee.setFirstname(emp.getFirstname());
			employee.setLastname(emp.getLastname());
			employee.setGender(emp.getGender());
			employee.setDob(emp.getDob());
			employee.setDepartment(emp.getDepartment());
			LOG.debug("message");

			employeeService.saveEmp(employee);
			System.out.print("Executed");
			//return (employee);
		}
		catch (Exception e) {
			
		}
		//return emp;
		
}

}
