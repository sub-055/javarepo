package com.employeeportal.DaoImpl;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.employeeportal.Dao.EmployeeRepository;
import com.employeeportal.Dao.GenericJpaDao;
import com.employeeportal.model.Employee;

@Repository
public class EmployeeRepositoryImpl extends GenericJpaDao<Employee,Integer> implements EmployeeRepository {

	@PersistenceContext
	EntityManager manager;
	
	public EmployeeRepositoryImpl() {
		super(Employee.class);
	}	
	
}
